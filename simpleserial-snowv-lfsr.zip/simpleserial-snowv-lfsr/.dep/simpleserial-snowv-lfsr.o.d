objdir-CW308_STM32F3/simpleserial-snowv-lfsr.o: simpleserial-snowv-lfsr.c \
 .././hal/hal.h .././hal/stm32f3/stm32f3_hal.h \
 .././simpleserial/simpleserial.h
.././hal/hal.h:
.././hal/stm32f3/stm32f3_hal.h:
.././simpleserial/simpleserial.h:
